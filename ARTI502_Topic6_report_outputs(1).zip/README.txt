ARTI 502 Topic 6 - Kaggle report-ready experiment outputs
Dataset: TweetEval hate (full train=9000, validation=1000, test=2970).
Positive class: hate=1. Model selection uses validation hate-class F1.
Hyperparameter and feature-selection comparisons: VALIDATION results only.
Final selected-model evaluation: held-out TEST results.
The notebook must actually be run to obtain real experimental scores.
